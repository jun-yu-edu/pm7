# sort : 메서드

# sorted : 함수

lst = [1, 5, 2, 4, 3]

sorted_lst = lst.sort()

print('list.sort()')
print('lst', lst)
print('sorted_lst', sorted_lst)

print()

lst = [1, 5, 2, 4, 3]

sorted_lst = sorted(lst)
print('sorted(list)')
print('lst', lst)
print('sorted_lst', sorted_lst)