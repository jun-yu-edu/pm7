lst = [1, 2, 3]

add_lst = [4, 5, 6]

# 1. 
lst.append(add_lst)
print(lst)
############################3

lst = [1, 2, 3]

# 2. 
lst.extend(add_lst)
# lst + add_lst
print(lst)